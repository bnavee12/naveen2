## Project Architecture
![Project Architecture](./project_architecture.png)

## Requirement:

We need to build a process for creating a file mover Lambda which will automatically moves the files from AWS SFTP to SFTP0 Humedica server. Because we will be completely moving out of the On-prem SFTP server to AWS SFTP so in between the migration process we are creating this temporary Lambda function to move the files from AWS SFTP (inside the client VM) to the On-prem SFTP0 server. 


Note: This file mover solution could be a short term one because this will get eliminated when we completely move all the servers to AWS cloud.


## Details about the Architecture: 

1.	The OPA files will be send from client VM through AWS SFTP server and it will reach to the AWS S3 bucket.
2.	A Lambda should be created which will watch the S3 bucket on specific interval time and help us to move the files from S3 to respective SFTP0 server.
3.	Lambda will receive inputs like “Hnumber, Streamid, Stream name, S3 bucket path, Provdata path” from the Dynamo DB.
4.	Inside the Lambda we will be incorporating the Errors & Exceptions mechanism. For any error related to the file transfer we will get triggered as a notification to the OPA team.
5.	Also, we will make the Lambda to run repeatedly (if it exceeds the run time of 15 minutes) until its finishes the complete transfer files.
6.	Cloud watch will monitor the Lambda and logs the failure events. In case of any errors in Lambda, it will be captured in log metrics. 
7.	The error logs will be sent to OPA team through email by using SNS.
 


## Lambda File mover Logic
Below are the steps for the AWS SFTP File Mover process:
1. Data Operations team will upload the files to be transferred in an S3 account.
2. Lambda will be triggered at specific interval.
3. Lambda will get the list of all the h_groups and stream_ids.
4. Lambda will get the corresponding details of a particular h_goup and stream_id from Dynamo DB.
5. This process will be done in a loop on interval basis.
   1) Open the sftp connection.
   2) Download the files to lambda /tmp storage.
   3) Sent the files to sftp0 server. On the location defined in dynamo db.
   4) Delete the file from S3 bucket.
   5) Close the sftp connection.
6)	If there is any error in lambda function then a failure mail will be sent from Cloudwatch alarms or by exception in lambda function.

## Resource Details

Below is the list of resources that will be created as part of this repo and the name of all these resources will have the same prefix that will be passed as input.

1. S3 bucket
2. Lambda
3. Dynamo DB table
4. SSM Parameter Store
5. CloudWatch (Logs, Alarms, Events)
6. SNS

## DyanmoDB Table Structure

Below is the structure of the DynamoDB tables and the names are case sensitive.

Table: ***OPA_Clients_Stream_Details***

|      ColumnName                  |      DataType     |      Sample             |
|----------------------------------|-------------------|-------------------------|
|     H_GroupId                    |     String        |     'H222'              |
|     Stream_ID                    |     Number        |     202101              |
|     On_Prem_Server               |     String        |     123.112.345.001     |
|     On_Prem_provdata_Location    |     String        |     /tmp/path           |
|     On_Prem_sftp_user            |     String        |     root                |
|     Stream_Name                  |     String        |                         |