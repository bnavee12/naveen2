import boto3
import os
import json
import logging
import traceback
import smtplib
import pysftp as sftp
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


logger = logging.getLogger(os.environ["AWS_LAMBDA_FUNCTION_NAME"])
logger.setLevel(logging.INFO)

DYNAMODB_TABLE = os.environ["CLIENT_CONFIG"]
AVERAGE_FILE_SIZE_MB = int(os.getenv("AVERAGE_FILE_SIZE_MB", '500'))
BUCKET = os.environ['BUCKET']

s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')
lambda_client = boto3.client('lambda')
ssm_client = boto3.client('ssm')
ddb_resource = boto3.resource('dynamodb')
ddb_table_object = ddb_resource.Table(DYNAMODB_TABLE)

def list_all_objects_from_bucket(prefix='/', Delimiter=None):
    """List all objects from bucket and object size should not be zero
    input: bucket and prefix
    output: List[Dict[s3_key_details]]
    """

    if Delimiter is None:
        Delimiter = ''

    objects = []
    # # prefix = "users/H123456/stream_id/202110/filename.txt"
    # prefix = '/' # f"users/{items['H_GroupId']}/stream_id/['streamid']/"
    response = s3_client.list_objects_v2(
        Bucket=BUCKET, # items['S3_Bucket_Id'],
        Prefix=prefix,
        Delimiter=Delimiter,
    )
    logger.debug(response)
    objects.extend(response['Contents'])
    while response.get('NextContinuationToken'):
        response = s3_client.list_objects_v2(
            Bucket=BUCKET, # items['S3_Bucket_Id'],
            Prefix=prefix,
            Delimiter=Delimiter,
            ContinuationToken=response['NextContinuationToken'],
        )
        objects.extend(response['Contents'])
    return [ object for object in objects if object['Size'] != 0]

def send_failure_email( msg_data) -> None:
    """Function to send Failure email in case of error"""

    response = ssm_client.get_parameter(Name=os.environ["SMTP_CREDS"],WithDecryption=True)
    smtp_creds = json.loads(response['Parameter']['Value'])
    logger.info('Sending Failure email to recipients')

    sender = 'oaextractionteam_dl@optum.com'
    receiver = os.environ["EMAIL_ADDRESS"]

    msg = MIMEMultipart()
    msg['Subject'] = 'File transfer Status'
    msg_body = {"lambda_function_name": "dev-sftp-filemover_lambda",
    "message": msg_data}
    msg.preamble = 'Multipart message.\n'
    part = MIMEText(str(msg_body), 'html')
    msg.attach(part)

    smtpObj = smtplib.SMTP("omail.o360.cloud", 587)
    smtpObj.starttls()
    smtpObj.login(smtp_creds['username'],smtp_creds['password'])
    smtpObj.sendmail(sender, receiver, msg.as_string())
    smtpObj.quit()

    logger.info('Successfully sent email')

def send_file_to_sftp_server(ddb_data, keys, ppk_file_data):
    """Download file from S3 then send file to sftp server then delete file from s3"""
    try:

        cnopts = sftp.CnOpts()
        cnopts.hostkeys = None 
        print(cnopts.hostkeys)

        sftpconnection = sftp.Connection(host=ddb_data['On_Prem_Server'], username=ddb_data['On_Prem_sftp_user'], private_key=ppk_file_data, cnopts=cnopts)
        logger.info("SFTP connetion successfully")

        for key in keys:
            filename = key.split('/')[-1]
            tmp_file_name = '/tmp/' + filename
            destination = ddb_data['On_Prem_provdata_Location']+'/'+filename

            s3_resource.meta.client.download_file(BUCKET, key, tmp_file_name)
            sftpconnection.put(tmp_file_name, destination)
            s3_client.delete_object(Bucket=BUCKET, Key=key)

        sftpconnection.close()
        logger.info("File uploaded successfully")

    except Exception as e:
        print("Exception occured while creating SFTP", e)
        print(traceback.print_exc())
        raise Exception(e)

def s3_keys_paginator(prefix=None, Delimiter=None):
    """Get a list of all the subdirectories inside S3 bucket prefix"""

    if prefix is None:
        prefix = ''
    if Delimiter is None:
        Delimiter = '/'

    prefixes = []

    paginator = s3_client.get_paginator("list_objects_v2")

    kwarg = {
        "Bucket": BUCKET,
        "Delimiter": Delimiter,  # list only keys/subfolders in users/ eg : ['users/h_group_id', 'users/folder/']
        "Prefix": prefix,
    }

    logger.debug(kwarg)

    for page in paginator.paginate(**kwarg):
        if page.get('CommonPrefixes'):
            prefixes.extend([key['Prefix'] for key in page['CommonPrefixes']])
        else:
            logger.info('No folders found in path %s',prefix )
    logger.debug(prefixes)
    return prefixes


def get_secret(username):
    """Get Secret From parameter Store connection"""
    try:
        client = boto3.client('ssm')
        value = client.get_parameter(Name="onprem-"+username, WithDecryption=True)['Parameter']['Value']
        return value
    except Exception as e:
        logging.exception(e)
        raise Exception("Failed to get ssm parameter")

def getclientconfig(h_groupid, stream_id):
    """Get details from Dynamodb"""
    logger.info('Fetching Client config details')
    key={'H_GroupId': h_groupid.split('/')[1], "Stream_ID": int(stream_id.split('/')[3])}
    logger.debug(key)
    client_config_data = ddb_table_object.get_item(Key=key)
    return client_config_data['Item']

def lambda_handler(event, context):
    """main function, Schedule Trigger by cloud watch event"""
    print(f"event : {event}")
    try:
        # put_item_dynamo_db_data()
        h_group_ids_keys = s3_keys_paginator(prefix='users/', Delimiter='/')

        all_keys = []
        temp_file_size = 0

        for h_group in h_group_ids_keys:

            stream_ids_keys = s3_keys_paginator(prefix=f"{h_group}stream_id/", Delimiter='/') # prefix = 'users/H123456/stream_id/'
            logger.debug(stream_ids_keys)
            for key in stream_ids_keys:
                object_keys = list_all_objects_from_bucket(prefix=key)
                dynamo_db_data = getclientconfig(h_groupid=h_group, stream_id=key)
                ppk_file_data = get_secret(dynamo_db_data['On_Prem_sftp_user'])

                for object in object_keys:
                    all_keys.append(object["Key"])
                    temp_file_size += object['Size']

                    if temp_file_size > (AVERAGE_FILE_SIZE_MB * 1024 * 1024):

                        send_file_to_sftp_server(dynamo_db_data, all_keys, ppk_file_data)
                        logger.info("Sent %d keys of Size %s MB to uploader lambda, Keys: %s", len(all_keys), str(round(temp_file_size/(1024*1024),5)), all_keys)

                        all_keys.clear()
                        temp_file_size = 0

                if temp_file_size != 0:
                    send_file_to_sftp_server(dynamo_db_data, all_keys, ppk_file_data)
                    logger.info("Sent %d keys of Size %s MB to uploader lambda, Keys: %s", len(all_keys), str(round(temp_file_size/(1024*1024),5)), all_keys)
                    all_keys.clear()
                    temp_file_size = 0
        # delete_item_dynamo_db_data()
    except Exception as e:
        logger.exception(e)
        traceback.print_exc()
        send_failure_email(e)
        # delete_item_dynamo_db_data()
        raise Exception(e)








# def put_item_dynamo_db_data():
#     response = ddb_table_object.put_item(
#         Item={
            
#                 "H_GroupId": "H12356",
#                 "Stream_ID": 202110,
#                 "Stream_Name": "Example/daily",
#                 "On_Prem_Server": "1.2.3.4",
#                 "On_Prem_provdata_Location": "/tmp/path"

#             },
#         )
# def delete_item_dynamo_db_data():
#     response = ddb_table_object.delete_item(
#     Key={
#             "H_GroupId": "H12356",
#             "Stream_ID": 202110,
        
# )
   
