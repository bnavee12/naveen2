# FILE MOVER FROM AWS SFTP TO HUMEDICA SFTP0 USING LAMBDA
Repository for aws_sftp_file_mover. This repository will be designed to support multiple environments:

Terraform layer for AWS_SFTP File Mover process. This repository will be designed to support multiple environments:

nonprod-shared - Contains account-level infrastructure for NonProduction/Non-PHI account (575066535343). It instantiates the persistent module, which includes AWS_SFTP-filemover account-level resources.

dev - contains a logical environment that sits on top of the infrastructure created by nonprod-shared environment. This can contain isolated infrastructure for development purposes.

Features

See persistent module and logical environment

Branching Strategy

The main branch is dev. Any changes to that branch will automatically be deployed to both the nonprod-shared and dev environments.

Once code has been tested, it can be promoted to the prod-shared branch. A merge to prod-shared will automatically execute a terraform plan on the prod-shared environment. However, because this has the potential to impact production workloads, in order to proceed with the terraform apply, the Jenkins build must be approved.

From there, code can continue to be promoted to dev-phi, qa, and stg branches. Merges to those branches will auto deploy to the corresponding logical environments with no approval needed in Jenkins. Once created, the prd branch and environment are expected to require approvals.

Build and Test Instructions

All developers should be using terraform 0.15.5 for this repository. Installing tfswitch is recommended to switch between terraform versions. Any changes should part of the persistent or base modules or their submodules. The developer workflow should involve updating one or both of those modules. Developers should be able to test that their terraform code works by:

1.changing their directory to either environments\nonprod-shared or environments\dev (depending on which they are updating)

2.Authenticate to AWS using the python authentication scripts.

3.terraform init

4.terraform plan

5.Review output plan to ensure it makes expected changes.

6.Create pull request with desired changes against the dev branch. The pull request in Jenkins will also start a terraform plan on both the nonprod-shared and dev environments.
